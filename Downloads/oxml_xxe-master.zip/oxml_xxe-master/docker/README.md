# Docker Build

This docker build is authored by 0xdevalias (https://github.com/0xdevalias/docker-oxml_xxe), maintained as part of oxml_xxe.

## To-do

- add docker-compose
- add instructions to build 
