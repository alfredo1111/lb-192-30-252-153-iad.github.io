The following are the credit for the files in the samples:

Created by BuffaloWill:
blank.docx
comments.docx
sample.docx
sample.pptx
sample.xlsx
test_odt.odt
xslt.docx

tunnel-depth.jpg - https://github.com/panrafal/depthy