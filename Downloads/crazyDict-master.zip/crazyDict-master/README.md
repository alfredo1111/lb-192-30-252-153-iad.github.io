crazyDict
=========

Dict lists using in fuzzing.
